# 18PlusAI

## Project Overview

18PlusAI is an innovative project designed to provide AI-driven solutions for adult content management and analysis. This project aims to harness the power of artificial intelligence to enhance the user experience, ensuring safe and responsible consumption of adult materials.

## Setup Instructions

Follow these steps to set up the 18PlusAI project on your local machine:

1. **Clone the repository**:
   ```bash
   git clone https://github.com/goody81/18PlusAI.git
   cd 18PlusAI
   ```

2. **Install dependencies**:
   Ensure you have Go installed on your machine. You can download it from [the official Go website](https://golang.org/dl/).

   Install the necessary dependencies by running:
   ```bash
   go mod tidy
   ```

3. **Run the application**:
   To start the application, use the following command:
   ```bash
   go run main.go
   ```

4. **Access the application**:
   Once the application is running, access it via your web browser at `http://localhost:8080`.

For further information, please refer to the documentation or the project's wiki.